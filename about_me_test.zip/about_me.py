my_name='Omokhuwele Umoru'
my_nickname='Omos'
my_age=23
used_python_before=True
favorite_hobbies=['Dancing','gaming','poetry','Reading']
fav_things={'Movie':'The Black Book','food':'Jollof rice'}
all_vars=dict(vars())